package com.voicecontrol.app

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class ArrowView(c: Context) : View(c) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 5f }
    override fun onDraw(c: Canvas) {
        val p = Path().apply {
            moveTo(0f, 0f); lineTo(0f, 80f); lineTo(22f, 60f); lineTo(40f, 95f)
            lineTo(55f, 88f); lineTo(38f, 54f); lineTo(65f, 52f); close()
        }
        c.drawPath(p, fill); c.drawPath(p, line)
    }
}

/** On-screen status bar, red arrow pointer and scroll hand. Needs no extra permission. */
class Overlay(private val ctx: Context) {
    private val ui = Handler(Looper.getMainLooper())
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val root = FrameLayout(ctx)
    private val bar = TextView(ctx)
    private val arrow = ArrowView(ctx)
    private val hand = TextView(ctx)
    private val hideBar = Runnable { bar.visibility = View.GONE }
    private val hideArrow = Runnable { arrow.visibility = View.GONE }
    private val hideHand = Runnable { hand.visibility = View.GONE }

    init {
        ui.post {
            bar.setTextColor(Color.WHITE); bar.textSize = 16f; bar.setPadding(40, 24, 40, 24); bar.visibility = View.GONE
            arrow.visibility = View.GONE
            hand.text = "👆"; hand.textSize = 48f; hand.visibility = View.GONE
            root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = 150 })
            root.addView(arrow, FrameLayout.LayoutParams(90, 100))
            root.addView(hand, FrameLayout.LayoutParams(-2, -2))
            val lp = WindowManager.LayoutParams(
                -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            wm.addView(root, lp)
        }
    }

    /** ok: null = working (⏳), true = done (green ✅), false = failed (red ❌) */
    fun say(t: String, ok: Boolean? = null) {
        ui.post {
            bar.text = (if (ok == true) "✅ " else if (ok == false) "❌ " else "⏳ ") + t
            bar.background = GradientDrawable().apply {
                cornerRadius = 48f
                setColor(if (ok == true) 0xEE2E7D32.toInt() else if (ok == false) 0xEEC62828.toInt() else 0xEE263238.toInt())
            }
            bar.visibility = View.VISIBLE
            ui.removeCallbacks(hideBar)
            ui.postDelayed(hideBar, if (ok == null) 15000 else 3500)
        }
    }

    fun point(x: Int, y: Int) {
        ui.post {
            arrow.visibility = View.VISIBLE
            ui.removeCallbacks(hideArrow)
            arrow.animate().translationX(x.toFloat()).translationY(y.toFloat()).setDuration(500).start()
            ui.postDelayed(hideArrow, 1800)
        }
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        ui.post {
            hand.translationX = x1 - 40; hand.translationY = y1 - 20
            hand.visibility = View.VISIBLE
            hand.animate().translationX(x2 - 40).translationY(y2 - 20).setDuration(ms).start()
            ui.removeCallbacks(hideHand)
            ui.postDelayed(hideHand, ms + 500)
        }
    }

    fun remove() { ui.post { try { wm.removeView(root) } catch (e: Exception) { } } }
}
