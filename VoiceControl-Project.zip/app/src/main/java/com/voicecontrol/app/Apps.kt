package com.voicecontrol.app

import android.content.Context
import android.content.Intent

object Apps {
    private val alias = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "व्हाट्स ऐप" to "whatsapp", "व्हाट्स एप" to "whatsapp",
        "व्हॉट्सएप" to "whatsapp", "वाट्सएप" to "whatsapp", "वाट्सऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "यूट्यूब" to "youtube", "यू ट्यूब" to "youtube", "फेसबुक" to "facebook", "इंस्टाग्राम" to "instagram",
        "इंस्टा" to "instagram", "टेलीग्राम" to "telegram", "क्रोम" to "chrome", "गैलरी" to "gallery",
        "कैमरा" to "camera", "सेटिंग्स" to "settings", "सेटिंग" to "settings", "जीमेल" to "gmail",
        "मैप्स" to "maps", "गूगल मैप" to "maps", "स्नैपचैट" to "snapchat", "प्ले स्टोर" to "play store",
        "कैलकुलेटर" to "calculator", "घड़ी" to "clock", "फोन" to "phone", "गूगल" to "google"
    )

    /** returns (label, packageName) */
    fun find(ctx: Context, q: String, min: Double = 0.6): Pair<String, String>? {
        var n = Match.norm(q)
        for ((k, v) in alias.entries.sortedByDescending { it.key.length }) if (n.contains(k)) n = n.replace(k, v)
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: Pair<String, String>? = null
        var bs = 0.0
        for (ri in list) {
            val label = ri.loadLabel(pm).toString()
            val s = Match.score(n, label)
            if (s >= min && (s > bs || (s == bs && label.length < (best?.first?.length ?: 999)))) {
                best = label to ri.activityInfo.packageName
                bs = s
            }
        }
        return best
    }
}
