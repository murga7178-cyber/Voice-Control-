package com.voicecontrol.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private class Step(val title: String, val ok: () -> Boolean, val guide: String, val act: () -> Unit)

    private lateinit var rows: LinearLayout
    private var dialog: AlertDialog? = null
    private var autoPrompt = true
    private var started = false
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private fun micOk() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun notifOk() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED
    private fun accOk(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private val steps by lazy {
        listOf(
            Step("🎤 माइक की अनुमति", { micOk() },
                "अगले बॉक्स में 'Allow' (या 'ऐप इस्तेमाल करते समय') दबाएँ।\n\nइसके बिना ऐप आपकी आवाज़ नहीं सुन पाएगा.",
                { askPerm(Manifest.permission.RECORD_AUDIO, 1, "micAsked", "Microphone") }),
            Step("🔔 नोटिफिकेशन की अनुमति", { notifOk() },
                "अगले बॉक्स में 'Allow' दबाएँ।\n\nइससे ऊपर दिखता रहेगा कि माइक चालू है.",
                { askPerm("android.permission.POST_NOTIFICATIONS", 2, "notifAsked", "Notifications") }),
            Step("♿ Accessibility चालू करें", { accOk() },
                "आगे खुलने वाली स्क्रीन में:\n\n1. 'Installed apps' या 'Downloaded apps' दबाएँ\n2. 'Voice Control' चुनें\n3. ऊपर का स्विच ON करें\n4. 'Allow' / 'ठीक है' दबाएँ\n\nस्विच ग्रे हो या चालू न हो, तो ऐप की मुख्य स्क्रीन पर 'स्विच ग्रे है?' वाला बटन दबाएँ.",
                { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        )
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun tv(s: String, sz: Float = 16f) = TextView(this).apply { text = s; textSize = sz; setPadding(0, 12, 0, 12) }
        fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
        l.addView(tv("🎙️ Voice Control", 26f))
        l.addView(tv("ज़रूरी अनुमतियाँ (किसी पर दबाकर ठीक करें):", 15f))
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        l.addView(rows)
        l.addView(btn("स्विच ग्रे है? (Restricted setting)") { restrictedGuide() })
        l.addView(tv("🧠 स्मार्ट समझ (वैकल्पिक): यहाँ Anthropic API key डालें तो पूरे वाक्य, हिंदी-अंग्रेज़ी मिलाकर और \"दस बजे भेज देना\" जैसे काम भी समझेगा. बिना key के सिर्फ़ सीधे कमांड चलेंगे.", 14f))
        val keyBox = EditText(this).apply {
            hint = "sk-ant-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        l.addView(keyBox)
        l.addView(btn("Key सेव करें") {
            prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
            Toast.makeText(this, "सेव हो गया", Toast.LENGTH_SHORT).show()
        })
        l.addView(btn("सुनना शुरू करें") { go() })
        l.addView(btn("सुनना बंद करें") { startService(Intent(this, MicService::class.java).setAction("STOP")) })
        l.addView(tv(HELP))
        setContentView(ScrollView(this).apply { addView(l) })
    }

    override fun onResume() {
        super.onResume()
        dialog?.dismiss()
        rows.removeAllViews()
        for (s in steps) {
            val ok = s.ok()
            rows.addView(TextView(this).apply {
                text = if (ok) "✅ ${s.title}" else "❌ ${s.title} — यहाँ दबाएँ"
                textSize = 18f
                setTextColor(if (ok) Color.rgb(46, 125, 50) else Color.rgb(198, 40, 40))
                setPadding(0, 16, 0, 16)
                setOnClickListener { if (!ok) prompt(s) }
            })
        }
        val next = steps.firstOrNull { !it.ok() }
        if (next == null) {
            rows.addView(TextView(this).apply { text = "🎉 सब तैयार! अब बोलिए."; textSize = 18f })
            if (!started) { started = true; go() }
        } else if (autoPrompt) prompt(next)
    }

    private fun prompt(s: Step) {
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this)
            .setTitle(s.title)
            .setMessage(s.guide)
            .setCancelable(false)
            .setPositiveButton("अनुमति दें →") { _, _ -> autoPrompt = true; s.act() }
            .setNegativeButton("बाद में") { _, _ -> autoPrompt = false }
            .show()
    }

    private fun askPerm(perm: String, code: Int, key: String, name: String) {
        if (!shouldShowRequestPermissionRationale(perm) && prefs.getBoolean(key, false)) {
            AlertDialog.Builder(this)
                .setTitle("$name की अनुमति")
                .setMessage("सिस्टम अब बॉक्स नहीं दिखा रहा, इसलिए हाथ से देनी होगी:\n\n1. 'ऐप जानकारी' खुलेगी\n2. 'Permissions' (अनुमतियाँ) दबाएँ\n3. '$name' दबाकर 'Allow' चुनें\n4. वापस आ जाएँ")
                .setPositiveButton("सेटिंग खोलें →") { _, _ -> openAppInfo() }
                .show()
        } else {
            prefs.edit().putBoolean(key, true).apply()
            requestPermissions(arrayOf(perm), code)
        }
    }

    private fun restrictedGuide() {
        AlertDialog.Builder(this)
            .setTitle("स्विच ग्रे है या बंद हो रहा है?")
            .setMessage("1. 'ऐप जानकारी' खुलेगी\n2. ऊपर दाएँ कोने में ⋮ (तीन बिंदु) दबाएँ\n3. 'Restricted settings की अनुमति दें' (Allow restricted settings) दबाएँ, फिर फ़ोन का लॉक/पिन माँगे तो डालें\n4. वापस आकर Accessibility फिर से चालू करें\n\n(⋮ न दिखे तो पहले Accessibility का स्विच एक बार दबाकर देखें, फिर यहाँ आएँ.)")
            .setPositiveButton("ऐप जानकारी खोलें →") { _, _ -> openAppInfo() }
            .setNegativeButton("बंद करें", null)
            .show()
    }

    private fun openAppInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
    }

    private fun go() {
        if (!micOk() || VoiceService.instance == null) {
            Toast.makeText(this, "पहले ऊपर की सारी अनुमतियाँ दें", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, MicService::class.java))
    }

    companion object {
        const val HELP = """बोलकर कमांड दें (हिंदी या English):

• "व्हाट्सएप खोलो" / "open WhatsApp" / सिर्फ़ "व्हाट्सएप"
• "स्क्रॉल करो" (नीचे) / "ऊपर" / "नीचे" / "left" / "right"
• "वापस" / "होम" / "रिसेंट" / "नोटिफिकेशन"
• "सर्च पर क्लिक करो" / सिर्फ़ स्क्रीन पर दिखता शब्द बोलें, जैसे "like"
• "कमेंट बहुत बढ़िया" → कमेंट बॉक्स ढूँढकर लिखेगा और पोस्ट करेगा
• "व्हाट्सएप में राहुल को हेलो लिख के सेंड कर दो"
• (key के साथ) "व्हाट्सएप खोलो और राहुल को सुबह वाला हाय गुड मॉर्निंग भेज देना, दस बजे के आसपास"
• "सब रद्द" → तय किए हुए काम हटा देगा
• "send hello to Rahul on WhatsApp"
• "लिखो नमस्ते" → जिस बॉक्स में कर्सर है उसमें लिखेगा
• "स्क्रीन लॉक करो" / "screen off" → पावर बटन की तरह स्क्रीन बंद (लॉक) होगी
• "रुको" → काम रोक देगा"""
    }
}
