package com.voicecontrol.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun tv(s: String, sz: Float = 16f) = TextView(this).apply { text = s; textSize = sz; setPadding(0, 12, 0, 12) }
        fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
        l.addView(tv("🎙️ Voice Control", 26f))
        l.addView(btn("1. Accessibility चालू करें") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        l.addView(btn("2. सुनना शुरू करें") { start() })
        l.addView(btn("सुनना बंद करें") { startService(Intent(this, MicService::class.java).setAction("STOP")) })
        l.addView(tv(HELP))
        setContentView(ScrollView(this).apply { addView(l) })
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) p.add("android.permission.POST_NOTIFICATIONS")
            requestPermissions(p.toTypedArray(), 1)
        } else go()
    }

    private fun go() {
        if (VoiceService.instance == null) {
            Toast.makeText(this, "पहले Accessibility में Voice Control चालू करें", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, MicService::class.java))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.firstOrNull() == PackageManager.PERMISSION_GRANTED) go()
    }

    companion object {
        const val HELP = """बोलकर कमांड दें (हिंदी या English):

• "व्हाट्सएप खोलो" / "open WhatsApp" / सिर्फ़ "व्हाट्सएप"
• "स्क्रॉल करो" (नीचे) / "ऊपर" / "नीचे" / "left" / "right"
• "वापस" / "होम" / "रिसेंट" / "नोटिफिकेशन"
• "सर्च पर क्लिक करो" / सिर्फ़ स्क्रीन पर दिखता शब्द बोलें, जैसे "like"
• "कमेंट बहुत बढ़िया" → कमेंट बॉक्स ढूँढकर लिखेगा और पोस्ट करेगा
• "व्हाट्सएप में राहुल को हेलो लिख के सेंड कर दो"
• "send hello to Rahul on WhatsApp"
• "लिखो नमस्ते" → जिस बॉक्स में कर्सर है उसमें लिखेगा
• "रुको" → काम रोक देगा"""
    }
}
