package com.voicecontrol.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class VoiceService : AccessibilityService() {

    companion object {
        @Volatile var instance: VoiceService? = null

        /** Screen text must match at least this much of the spoken word (0.3 = 30%). Lower = more lenient. */
        const val MIN_SCORE = 0.55

        private val STOP = setOf("stop", "cancel", "रुको", "रुक", "रोको", "बंद")
        private val OPEN = setOf("open", "launch", "start", "खोलो", "खोल", "खोलिए", "खोलें", "ओपन", "चालू", "kholo", "khol")
        private val CLICK = setOf("click", "tap", "press", "क्लिक", "टैप", "दबाओ", "दबा", "dabao")
        private val FILL = setOf("करो", "कर", "दो", "please", "प्लीज", "पर", "को", "on", "the", "जाओ")
        private val SCROLLW = setOf("scroll", "स्क्रॉल", "स्क्रोल", "swipe", "स्वाइप", "स्क्रॉलकरो", "scrolling")
        private val UP = setOf("up", "ऊपर", "upar", "ऊपेर", "ऊपरको", "top")
        private val DOWN = setOf("down", "नीचे", "niche", "नीचा", "नीचेको", "bottom")
        private val LEFT = setOf("left", "बाएं", "बायें", "बाएँ", "bayen")
        private val RIGHT = setOf("right", "दाएं", "दायें", "दाएँ", "dayen")
        private val BACK = setOf("back", "वापस", "पीछे", "piche", "पीछेहो", "backward")
        private val HOME = setOf("home", "होम")
        private val RECENT = setOf("recent", "recents", "रिसेंट")
        private val NOTIF = setOf("notification", "notifications", "नोटिफिकेशन")
        private val COMMENTW = setOf("comment", "कमेंट", "कमेन्ट", "कॉमेंट", "टिप्पणी")
        private val TYPEW = setOf("type", "लिखो", "लिख")

        private val SEARCH = listOf("search", "सर्च", "खोज", "ask meta ai or search")
        private val MSGBOX = listOf("message", "type a message", "मैसेज", "संदेश")
        private val SEND = listOf("send", "सेंड", "भेजें", "भेजो")
        private val COMMENT = listOf("add a comment", "comment", "कमेंट", "टिप्पणी")
        private val POST = listOf("post", "send", "पोस्ट", "भेजें", "सेंड")

        private val hiMsg = Regex(
            "(.+?) (?:में|मे|me|mein|mai) (.+?) (?:को|ko) (.+?) (?:लिख\\S*|भेज\\S*|likh\\S*|bhej\\S*|send)(?: .*)?",
            RegexOption.IGNORE_CASE
        )
        private val enMsg = Regex("(?:send|write|message|text) (.+?) to (.+?)(?: (?:on|in|via|using) (.+))?", RegexOption.IGNORE_CASE)
    }

    private lateinit var ov: Overlay
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var cancel = false
    @Volatile private var awaitingMessageText = false
    @Volatile private var awaitingMessageSend = false
    @Volatile private var pendingRepeat: Triple<String, String, Int>? = null
    @Volatile private var pendingClickTarget: String? = null
    @Volatile private var lastClickedTarget: String? = null

    override fun onServiceConnected() {
        ov = Overlay(this)
        instance = this
        Crash.note(this, "service connected")
        keepAlive()
        try { ov.say("Voice Control तैयार ✔ — ऐप में 'सुनना शुरू करें' दबाएँ", true) } catch (e: Throwable) { }
    }

    /** Foreground notification so phone "cleaners" are less likely to kill the service. */
    private fun keepAlive() {
        try {
            val ch = "alive"
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "Voice Control चालू", NotificationManager.IMPORTANCE_LOW))
            val n = Notification.Builder(this, ch).setContentTitle("Voice Control चालू है")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(2, n)
        } catch (e: Throwable) { }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { Crash.note(this, "interrupt") }
    override fun onUnbind(intent: Intent?): Boolean { Crash.note(this, "unbind (system disconnected)"); return super.onUnbind(intent) }
    override fun onDestroy() { Crash.note(this, "service destroy"); instance = null; if (::ov.isInitialized) ov.remove(); super.onDestroy() }

    fun status(t: String) { if (::ov.isInitialized) ov.say(t, true) }

    /** Called by MicService with every spoken sentence. */
    fun onHeard(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        if (Match.norm(t).split(" ").any { it == "रद्द" || it == "रद" }) {
            clearScheduled(); cancel = true
            ov.say("सब रद्द कर दिया", true)
            return
        }
        val tk = Match.norm(t).split(" ")
        val lockish = tk.any { it == "lock" || it == "लॉक" } ||
            (tk.any { it == "screen" || it == "स्क्रीन" } && tk.any { it == "off" || it == "ऑफ" || it == "बंद" })
        if (lockish && tk.size <= 5) {
            ov.say("स्क्रीन लॉक कर रहा हूँ", true)
            worker.execute { nap(900); performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) }
            return
        }
        if (Match.norm(t).split(" ").any { it in STOP }) {
            cancel = true
            ov.say("रुक गया", true)
            return
        }
        ov.say("सुना: $t")
        worker.execute {
            try { cancel = false; handle(t) } catch (e: Exception) { ov.say("गड़बड़: ${e.message}", false) }
        }
    }

    // ---------------------------------------------------------------- smart (AI) understanding + schedule

    private val timer = Handler(Looper.getMainLooper())
    private val pending = mutableListOf<Runnable>()

    private fun handle(raw0: String) {
        val tokens = Match.norm(raw0).split(" ").filter { it.isNotEmpty() }
        if (tokens.size <= 2 || Ai.key(this).isEmpty()) { local(raw0); return }
        ov.say("समझ रहा हूँ…")
        val p = try { Ai.plan(this, raw0.trim()) } catch (e: Exception) {
            ov.say("AI नहीं चला (${e.message}) — सीधा तरीका आज़मा रहा हूँ", false); nap(1500); null
        }
        if (p == null) { local(raw0); return }
        val arr = p.optJSONArray("steps") ?: JSONArray()
        if (arr.length() == 0) { ov.say(p.optString("note").ifBlank { "समझ नहीं आया" }, false); return }
        val list = mutableListOf<Pair<String, () -> Boolean>>()
        for (i in 0 until arr.length()) list += stepsFor(arr.getJSONObject(i))
        val at = p.optString("at", "")
        if (at.matches(Regex("\\d{1,2}:\\d{2}"))) schedule(at, list) else run("काम", list)
    }

    private fun stepsFor(o: JSONObject): List<Pair<String, () -> Boolean>> {
        return when (o.optString("a")) {
            "open" -> { val a = o.optString("app"); listOf("$a खोल रहा हूँ" to { openApp(a) }) }
            "message" -> msgSteps(o.optString("app").ifBlank { "whatsapp" }, o.optString("name"), o.optString("text"))
            "click" -> { val t = o.optString("text"); listOf("'$t' ढूँढ रहा हूँ" to { click(listOf(t)) }) }
            "type" -> { val t = o.optString("text"); listOf("'$t' लिख रहा हूँ" to { type(t) }) }
            "comment" -> commentSteps(o.optString("text"))
            "scroll" -> { val d = o.optString("dir", "down"); listOf("स्क्रॉल कर रहा हूँ" to { scroll(d) }) }
            "back" -> listOf("वापस जा रहा हूँ" to { performGlobalAction(GLOBAL_ACTION_BACK) })
            "home" -> listOf("होम पर जा रहा हूँ" to { performGlobalAction(GLOBAL_ACTION_HOME) })
            "lock" -> listOf("स्क्रीन लॉक कर रहा हूँ" to { nap(800); performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) })
            "wait" -> { val n = o.optInt("sec", 2); listOf("$n सेकंड रुक रहा हूँ" to { nap(n * 1000L); true }) }
            else -> emptyList()
        }
    }

    private fun commentSteps(text: String): List<Pair<String, () -> Boolean>> = listOf(
        "कमेंट बॉक्स ढूँढ रहा हूँ" to { click(COMMENT) },
        "टेक्स्ट बॉक्स चुन रहा हूँ" to { click(COMMENT, true, 2500); true },
        "'$text' लिख रहा हूँ" to { type(text) },
        "पोस्ट कर रहा हूँ" to { click(POST) }
    )

    private fun schedule(at: String, list: List<Pair<String, () -> Boolean>>) {
        val (h, m) = at.split(":").map { it.toInt() }
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0) }
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        val r = Runnable { wake(); worker.execute { cancel = false; run("तय किया हुआ काम", list) } }
        synchronized(pending) { pending.add(r) }
        timer.postDelayed(r, c.timeInMillis - System.currentTimeMillis())
        ov.say("%02d:%02d बजे यह काम करूँगा (फ़ोन चालू और अनलॉक रखें)".format(h, m), true)
    }

    private fun clearScheduled() {
        synchronized(pending) { pending.forEach { timer.removeCallbacks(it) }; pending.clear() }
    }

    @Suppress("DEPRECATION")
    private fun wake() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "vc:wake").acquire(120000)
    }

    // ---------------------------------------------------------------- command parsing

    private fun local(raw0: String) {
        val raw = raw0.trim().trimEnd('.', '!', '?', '।')
        val tokens = Match.norm(raw).split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return
        val normRaw = Match.norm(raw)

        // Handle short answers to a question before treating them as a new action.
        val yesWords = setOf("हाँ", "हां", "जी", "हाँ जी", "yes", "yeah", "yep", "ठीक", "ठीक है", "करो", "कर दीजिए", "haan", "han")
        val noWords = setOf("नहीं", "नही", "ना", "no", "nope", "गलत", "दूसरा", "दूसरा वाला", "पीछे वाला", "ये नहीं", "यह नहीं")
        if (pendingRepeat != null) {
            if (normRaw in yesWords || normRaw.startsWith("हाँ ") || normRaw.startsWith("हां ") || normRaw.startsWith("yes ")) {
                val req = pendingRepeat!!; pendingRepeat = null
                run("बार-बार संदेश भेजना", repeatedMessageSteps(req.first, req.second, req.third))
                return
            }
            if (normRaw in noWords || normRaw.startsWith("नहीं ") || normRaw.startsWith("गलत") || (normRaw.contains("नहीं") && (normRaw.contains("पीछे") || normRaw.contains("दूसरा") || normRaw.contains("यह") || normRaw.contains("ये")))) {
                pendingRepeat = null
                ov.say("ठीक है, मैं संदेश नहीं भेजूँगी। बताइए, किस व्यक्ति को और क्या लिखना है?")
                MicService.speak("ठीक है, मैं संदेश नहीं भेजूँगी। बताइए, किस व्यक्ति को और क्या लिखना है?")
                return
            }
        }
        if (pendingClickTarget != null) {
            if (normRaw in yesWords || normRaw.startsWith("हाँ ") || normRaw.startsWith("हां ") || normRaw.startsWith("yes ")) {
                val target = pendingClickTarget!!; pendingClickTarget = null
                run("स्क्रीन पर विकल्प चुनना", listOf("'$target' ढूँढ रही हूँ" to { click(listOf(target)) }))
                return
            }
            if (normRaw in noWords || normRaw.startsWith("नहीं ") || normRaw.startsWith("गलत") || (normRaw.contains("नहीं") && (normRaw.contains("पीछे") || normRaw.contains("दूसरा") || normRaw.contains("यह") || normRaw.contains("ये")))) {
                val old = pendingClickTarget!!; pendingClickTarget = null
                if (normRaw.contains("पीछे") || normRaw.contains("back") || normRaw.contains("दूसरा")) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    ov.say("ठीक है, पीछे आ गई हूँ। '$old' नहीं चुनूँगी। अब बताइए, कौन-सा दूसरा विकल्प चुनना है?")
                    MicService.speak("ठीक है, पीछे आ गई हूँ। वह विकल्प नहीं चुनूँगी। अब बताइए, कौन-सा दूसरा विकल्प चुनना है?")
                } else {
                    ov.say("ठीक है, वह नहीं चुनूँगी। स्क्रीन पर जो सही विकल्प लिखा है, उसका नाम बताइए।")
                    MicService.speak("ठीक है, वह नहीं चुनूँगी। स्क्रीन पर जो सही विकल्प लिखा है, उसका नाम बताइए।")
                }
                return
            }
        }

        // A repeated-send request is confirmed before any messages are sent.
        val repeatCount = when {
            Regex("\\b100\\b").containsMatchIn(normRaw) || normRaw.contains("सौ बार") -> 100
            Regex("\\b(\\d{1,2})\\s+बार").find(normRaw)?.groupValues?.getOrNull(1)?.toIntOrNull() != null -> Regex("\\b(\\d{1,2})\\s+बार").find(normRaw)!!.groupValues[1].toInt()
            normRaw.contains("दस बार") -> 10
            normRaw.contains("बीस बार") -> 20
            normRaw.contains("पचास बार") -> 50
            else -> 0
        }
        if (repeatCount in 2..100 && (normRaw.contains("भेज") || normRaw.contains("send")) && (normRaw.contains("को") || normRaw.contains(" to "))) {
            val koIndex = raw.indexOf("को")
            val toMatch = Regex("(?i)\\bto\\b").find(raw)
            val recipient = if (koIndex >= 0) raw.substring(0, koIndex).trim()
                else if (toMatch != null) raw.substring(0, toMatch.range.first).trim() else ""
            var body = if (koIndex >= 0) raw.substring(koIndex + "को".length).trim()
                else if (toMatch != null) raw.substring(toMatch.range.last + 1).trim() else ""
            body = body.replace(Regex("(?:100|\\d{1,2}|सौ|दस|बीस|पचास)\\s*बार.*$", RegexOption.IGNORE_CASE), "")
                .replace(Regex("(?:लिख कर|लिखकर|लिख के|भेज दो|भेजो|भेज दीजिए|send it|send)$", RegexOption.IGNORE_CASE), "").trim()
            body = body.replace(Regex("^(?:मैसेज में|message|msg)\\s+", RegexOption.IGNORE_CASE), "").trim()
            if (body in setOf("हाय है", "हाय हाय", "hi hi", "हाई हाई")) body = "Hi Hi"
            if (recipient.isNotBlank() && body.isNotBlank()) {
                pendingRepeat = Triple(recipient, body, repeatCount)
                val ask = "$recipient को '$body' के $repeatCount अलग-अलग संदेश भेजने हैं। यह कई संदेश भेजेगा। शुरू करूँ? हाँ या नहीं बोलें।"
                ov.say(ask); MicService.speak(ask)
                return
            }
        }

        // Read visible screen/video titles aloud when explicitly requested.
        val readPhrases = listOf("क्या लिखा है", "स्क्रीन पढ़ो", "स्क्रीन पर क्या है", "पढ़कर सुनाओ", "नाम पढ़ो", "वीडियो का नाम", "read screen", "read this", "what is written", "read the title", "read video title")
        if (readPhrases.any { normRaw.contains(Match.norm(it)) }) {
            val spoken = visibleScreenText()
            if (spoken.isBlank()) {
                ov.say("माफ़ कीजिए, मुझे स्क्रीन का टेक्स्ट दिखाई नहीं दे रहा है। आप बताइए, आप क्या करना चाहते हैं?", false)
                MicService.speak("माफ़ कीजिए, मुझे स्क्रीन का टेक्स्ट दिखाई नहीं दे रहा है। क्या आप इसे दूसरी तरह से बता सकते हैं?")
            } else {
                ov.say("स्क्रीन का टेक्स्ट पढ़ रहा हूँ", true)
                MicService.speak(spoken.take(900))
            }
            return
        }

        // Navigation commands accept natural Hindi, Hinglish, and English phrasing.
        val backPhrases = listOf(
            "एक कदम पीछे", "एक स्टेप पीछे", "एक स्टेप बैक", "थोड़ा पीछे", "थोड़ा पीछे",
            "पीछे जाओ", "पीछे हो जाओ", "बैक करो", "बैक हो जाओ", "एक कदम बैक",
            "go back", "step back", "one step back", "back one step", "go backward", "back"
        )
        if (backPhrases.any { normRaw == Match.norm(it) || normRaw.startsWith(Match.norm(it) + " ") } ||
            (tokens.any { it in BACK } && tokens.any { it in setOf("एक", "स्टेप", "कदम", "थोड़ा", "थोड़ा", "जाओ", "करो", "हो", "go", "step", "one") })) {
            run("एक कदम पीछे", listOf("एक कदम पीछे जा रहा हूँ" to { performGlobalAction(GLOBAL_ACTION_BACK) }))
            return
        }

        val closePhrases = listOf(
            "ऐप बंद करो", "एप बंद करो", "एप्लिकेशन बंद करो", "इस ऐप को बंद करो", "इस एप्लिकेशन को बंद करो",
            "बंद करके बाहर आओ", "मिनिमाइज करो", "मिनिमाइज़ करो", "close app", "close this app",
            "minimize app", "minimise app", "exit app", "application बंद करो"
        )
        if (closePhrases.any { normRaw == Match.norm(it) || normRaw.startsWith(Match.norm(it) + " ") } ||
            (tokens.any { it in setOf("close", "minimize", "minimise", "exit", "बंद", "मिनिमाइज", "मिनिमाइज़") } &&
             tokens.any { it in setOf("app", "application", "ऐप", "एप", "एप्लिकेशन", "इस") })) {
            run("ऐप को मिनिमाइज करना", listOf("ऐप को स्क्रीन से हटाकर होम पर जा रहा हूँ" to { performGlobalAction(GLOBAL_ACTION_HOME) }))
            status("ऐप मिनिमाइज हो गया। बताइए, अब कौन-सा ऐप खोलना है या क्या चेक करना है?")
            return
        }

        // Multi-turn message composition: open the message box, dictate text, then say send.
        if (awaitingMessageText) {
            awaitingMessageText = false
            awaitingMessageSend = true
            run("मैसेज लिखना", listOf("'$raw' लिख रहा हूँ" to { type(raw) }))
            status("मैसेज लिखा है। भेजने के लिए 'सेंड' या 'भेजो' बोलें।")
            return
        }
        if (awaitingMessageSend && tokens.any { it in SEND || it == "send" || it == "भेजो" || it == "भेज" }) {
            awaitingMessageSend = false
            run("मैसेज भेजना", listOf("भेज रहा हूँ" to { click(SEND, false) }))
            return
        }
        if (tokens.any { it in MSGBOX || it == "message" || it == "मैसेज" || it == "संदेश" } &&
            (tokens.any { it in FILL } || tokens.size <= 3)) {
            awaitingMessageText = true
            awaitingMessageSend = false
            run("मैसेज बॉक्स", listOf("मैसेज बॉक्स खोल रहा हूँ" to { click(MSGBOX, true) }))
            status("अब अपना मैसेज बोलिए। लिखने के बाद 'सेंड' बोलें।")
            return
        }

        hiMsg.matchEntire(raw)?.let { m -> sendMsg(m.groupValues[1], m.groupValues[2], m.groupValues[3]); return }
        enMsg.matchEntire(raw)?.let { m ->
            sendMsg(m.groupValues[3].ifBlank { "whatsapp" }, m.groupValues[2], m.groupValues[1]); return
        }

        if (tokens[0] in COMMENTW) {
            val text = raw.split(Regex("\\s+")).drop(1).joinToString(" ").replace(Regex("^(करो|कर|लिखो|लिख|that|:)\\s+"), "")
            if (text.isBlank()) run("कमेंट", listOf("कमेंट बॉक्स ढूँढ रहा हूँ" to { click(COMMENT) }))
            else run("कमेंट", listOf(
                "कमेंट बॉक्स ढूँढ रहा हूँ" to { click(COMMENT) },
                "टेक्स्ट बॉक्स चुन रहा हूँ" to { click(COMMENT, true, 2500); true },
                "'$text' लिख रहा हूँ" to { type(text) },
                "पोस्ट कर रहा हूँ" to { click(POST) }
            ))
            return
        }

        if (tokens[0] in TYPEW && tokens.size > 1) {
            val text = raw.split(Regex("\\s+")).drop(1).joinToString(" ")
            run("टाइपिंग", listOf("'$text' लिख रहा हूँ" to { type(text) }))
            return
        }

        if (tokens.size <= 5) {
            val g = when {
                tokens.any { it in BACK } -> GLOBAL_ACTION_BACK to "वापस जा रहा हूँ"
                tokens.any { it in HOME } -> GLOBAL_ACTION_HOME to "होम पर जा रहा हूँ"
                tokens.any { it in RECENT } -> GLOBAL_ACTION_RECENTS to "रिसेंट खोल रहा हूँ"
                tokens.any { it in NOTIF } -> GLOBAL_ACTION_NOTIFICATIONS to "नोटिफिकेशन खोल रहा हूँ"
                else -> null
            }
            if (g != null) { run(g.second, listOf(g.second to { performGlobalAction(g.first) })); return }
        }

        if (tokens.any { it in SCROLLW } || (tokens.size <= 2 && tokens.any { it in UP + DOWN + LEFT + RIGHT })) {
            val dir = when {
                tokens.any { it in UP } -> "up"
                tokens.any { it in LEFT } -> "left"
                tokens.any { it in RIGHT } -> "right"
                else -> "down"
            }
            val name = mapOf("up" to "ऊपर", "down" to "नीचे", "left" to "बाएं", "right" to "दाएं")[dir]
            run("स्क्रॉल", listOf("$name स्क्रॉल कर रहा हूँ" to { scroll(dir) }))
            return
        }

        val target = tokens.filter { it !in OPEN && it !in CLICK && it !in FILL }.joinToString(" ")

        if (tokens.any { it in OPEN } && target.isNotBlank()) {
            run("ऐप खोलना", listOf("$target खोल रहा हूँ" to { openApp(target) }))
            return
        }
        if (tokens.any { it in CLICK } && target.isNotBlank()) {
            run("क्लिक", listOf("'$target' ढूँढ रहा हूँ" to { click(listOf(target)) }))
            return
        }

        // Only a word was spoken: installed app name -> open it, otherwise click that word on screen.
        if (tokens.size <= 3 && Apps.find(this, target, 0.75) != null) {
            run("ऐप खोलना", listOf("$target खोल रहा हूँ" to { openApp(target) }))
        } else if (target.isNotBlank()) {
            pendingClickTarget = target
            val ask = "मैं स्क्रीन पर '$target' विकल्प ढूँढ सकती हूँ। क्या यही चुनना था? हाँ या नहीं बोलें।"
            ov.say(ask); MicService.speak(ask)
        } else {
            val ask = "माफ़ कीजिए, मैं आपकी बात समझ नहीं पाई। आप बताइए, आप क्या करना चाहते हैं?"
            ov.say(ask, false); MicService.speak(ask)
        }
    }

    private fun sendMsg(appQ: String, name: String, text: String) = run("संदेश भेजना", msgSteps(appQ, name, text))

    private fun msgSteps(appQ: String, name: String, text: String): List<Pair<String, () -> Boolean>> {
        return listOf(
            "$appQ खोल रहा हूँ" to { openApp(appQ) },
            "सर्च दबा रहा हूँ" to { click(SEARCH) },
            "'$name' लिख रहा हूँ" to { type(name) },
            "'$name' चुन रहा हूँ" to { nap(1200); click(listOf(name), false) },
            "मैसेज बॉक्स ढूँढ रहा हूँ" to { click(MSGBOX, true) },
            "'$text' लिख रहा हूँ" to { type(text) },
            "भेज रहा हूँ" to { click(SEND, false) }
        )
    }

    private fun repeatedMessageSteps(name: String, text: String, count: Int): List<Pair<String, () -> Boolean>> {
        val steps = mutableListOf<Pair<String, () -> Boolean>>()
        steps += "WhatsApp खोल रही हूँ" to { openApp("whatsapp") }
        steps += "सर्च खोल रही हूँ" to { click(SEARCH) }
        steps += "'$name' खोज रही हूँ" to { type(name) }
        steps += "'$name' संपर्क चुन रही हूँ" to { nap(1200); click(listOf(name), false) }
        steps += "मैसेज बॉक्स ढूँढ रही हूँ" to { click(MSGBOX, true) }
        for (i in 1..count) {
            steps += "$i/$count: संदेश लिख रही हूँ" to { type(text) }
            steps += "$i/$count: संदेश भेज रही हूँ" to { click(SEND, false) }
            if (i < count) steps += "अगले संदेश की तैयारी" to { nap(900); true }
        }
        return steps
    }

    // ---------------------------------------------------------------- step runner

    private fun run(title: String, steps: List<Pair<String, () -> Boolean>>) {
        for ((label, fn) in steps) {
            if (cancel) return
            ov.say(label)
            MicService.speak(label)
            val ok = try { fn() } catch (e: Exception) { false }
            if (cancel) return
            if (!ok) {
                val apology = "माफ़ कीजिए, यह काम नहीं हो पाया। मुझे स्क्रीन पर सही चीज़ नहीं मिली। आप बताइए, आप क्या करना चाहते हैं? इसे दूसरे तरीके से बता सकती हैं।"
                ov.say(apology, false); MicService.speak(apology); return
            }
            ov.say("$label — हो गया", true)
            nap(700)
        }
        ov.say("$title पूरा", true)
        MicService.speak("हो गया। बताइए, अब क्या करना है?")
    }

    private fun visibleScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val out = LinkedHashSet<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= 30) return
            if (n.isVisibleToUser) {
                listOf(n.text, n.contentDescription).forEach { value ->
                    val v = value?.toString()?.trim().orEmpty()
                    if (v.length >= 2 && v.length <= 180) out.add(v)
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out.joinToString(". ")
    }

    private fun nap(ms: Long) {
        var left = ms
        while (left > 0 && !cancel) { Thread.sleep(minOf(left, 100)); left -= 100 }
    }

    // ---------------------------------------------------------------- actions

    private fun openApp(q: String): Boolean {
        val a = Apps.find(this, q) ?: return false
        val intent = packageManager.getLaunchIntentForPackage(a.second) ?: return false
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val end = SystemClock.uptimeMillis() + 8000
        while (SystemClock.uptimeMillis() < end && !cancel) {
            nap(300)
            if (rootInActiveWindow?.packageName == a.second) { nap(1500); return true }
        }
        return false
    }

    private fun click(qs: List<String>, edit: Boolean? = null, wait: Long = 6000): Boolean {
        val end = SystemClock.uptimeMillis() + wait
        while (SystemClock.uptimeMillis() < end && !cancel) {
            val hit = Finder.best(rootInActiveWindow, qs, edit)
            if (hit != null) {
                val r = Rect()
                hit.getBoundsInScreen(r)
                ov.point(r.centerX(), r.centerY())
                nap(700)
                doClick(hit, r)
                nap(500)
                return true
            }
            nap(400)
        }
        return false
    }

    private fun doClick(node: AccessibilityNodeInfo, r: Rect) {
        if (node.isEditable) { node.performAction(AccessibilityNodeInfo.ACTION_CLICK); node.performAction(AccessibilityNodeInfo.ACTION_FOCUS); return }
        var n: AccessibilityNodeInfo? = node
        var d = 0
        while (n != null && d < 7) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            n = n.parent
            d++
        }
        gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 60)
    }

    private fun type(text: String): Boolean {
        nap(500)
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: Finder.firstEditable(root) ?: return false
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val ok = f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        nap(500)
        return ok
    }

    private fun scroll(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val (x1, y1, x2, y2) = when (dir) {
            "up" -> listOf(w / 2, h * 0.30f, w / 2, h * 0.75f)
            "down" -> listOf(w / 2, h * 0.75f, w / 2, h * 0.30f)
            "left" -> listOf(w * 0.80f, h / 2, w * 0.20f, h / 2)
            else -> listOf(w * 0.20f, h / 2, w * 0.80f, h / 2)
        }
        ov.swipe(x1, y1, x2, y2, 700)
        nap(300)
        return gesture(x1, y1, x2, y2, 600)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        val latch = CountDownLatch(1)
        var ok = false
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(4, TimeUnit.SECONDS)
        return ok
    }
}
