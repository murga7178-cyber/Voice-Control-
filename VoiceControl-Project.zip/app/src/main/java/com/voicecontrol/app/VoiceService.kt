package com.voicecontrol.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class VoiceService : AccessibilityService() {

    companion object {
        @Volatile var instance: VoiceService? = null

        /** Screen text must match at least this much of the spoken word (0.3 = 30%). Lower = more lenient. */
        const val MIN_SCORE = 0.3

        private val STOP = setOf("stop", "cancel", "रुको", "रुक", "रोको", "बंद")
        private val OPEN = setOf("open", "launch", "start", "खोलो", "खोल", "खोलिए", "खोलें", "ओपन", "चालू", "kholo", "khol")
        private val CLICK = setOf("click", "tap", "press", "क्लिक", "टैप", "दबाओ", "दबा", "dabao")
        private val FILL = setOf("करो", "कर", "दो", "please", "प्लीज", "पर", "को", "on", "the", "जाओ")
        private val SCROLLW = setOf("scroll", "स्क्रॉल", "स्क्रोल", "swipe", "स्वाइप")
        private val UP = setOf("up", "ऊपर", "upar")
        private val DOWN = setOf("down", "नीचे", "niche")
        private val LEFT = setOf("left", "बाएं", "बायें", "बाएँ", "bayen")
        private val RIGHT = setOf("right", "दाएं", "दायें", "दाएँ", "dayen")
        private val BACK = setOf("back", "वापस", "पीछे", "piche")
        private val HOME = setOf("home", "होम")
        private val RECENT = setOf("recent", "recents", "रिसेंट")
        private val NOTIF = setOf("notification", "notifications", "नोटिफिकेशन")
        private val COMMENTW = setOf("comment", "कमेंट", "कमेन्ट", "कॉमेंट", "टिप्पणी")
        private val TYPEW = setOf("type", "लिखो", "लिख")

        private val SEARCH = listOf("search", "सर्च", "खोज", "ask meta ai or search")
        private val MSGBOX = listOf("message", "type a message", "मैसेज", "संदेश")
        private val SEND = listOf("send", "सेंड", "भेजें", "भेजो")
        private val COMMENT = listOf("add a comment", "comment", "कमेंट", "टिप्पणी")
        private val POST = listOf("post", "send", "पोस्ट", "भेजें", "सेंड")

        private val hiMsg = Regex(
            "(.+?) (?:में|मे|me|mein|mai) (.+?) (?:को|ko) (.+?) (?:लिख\\S*|भेज\\S*|likh\\S*|bhej\\S*|send)(?: .*)?",
            RegexOption.IGNORE_CASE
        )
        private val enMsg = Regex("(?:send|write|message|text) (.+?) to (.+?)(?: (?:on|in|via|using) (.+))?", RegexOption.IGNORE_CASE)
    }

    private lateinit var ov: Overlay
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var cancel = false

    override fun onServiceConnected() {
        instance = this
        ov = Overlay(this)
        ov.say("Voice Control तैयार ✔ — ऐप में 'सुनना शुरू करें' दबाएँ", true)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; if (::ov.isInitialized) ov.remove(); super.onDestroy() }

    fun status(t: String) { if (::ov.isInitialized) ov.say(t, true) }

    /** Called by MicService with every spoken sentence. */
    fun onHeard(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        if (Match.norm(t).split(" ").any { it in STOP }) {
            cancel = true
            ov.say("रुक गया", true)
            return
        }
        ov.say("सुना: $t")
        worker.execute {
            try { cancel = false; handle(t) } catch (e: Exception) { ov.say("गड़बड़: ${e.message}", false) }
        }
    }

    // ---------------------------------------------------------------- command parsing

    private fun handle(raw0: String) {
        val raw = raw0.trim().trimEnd('.', '!', '?', '।')
        val tokens = Match.norm(raw).split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return

        hiMsg.matchEntire(raw)?.let { m -> sendMsg(m.groupValues[1], m.groupValues[2], m.groupValues[3]); return }
        enMsg.matchEntire(raw)?.let { m ->
            sendMsg(m.groupValues[3].ifBlank { "whatsapp" }, m.groupValues[2], m.groupValues[1]); return
        }

        if (tokens[0] in COMMENTW) {
            val text = raw.split(Regex("\\s+")).drop(1).joinToString(" ").replace(Regex("^(करो|कर|लिखो|लिख|that|:)\\s+"), "")
            if (text.isBlank()) run("कमेंट", listOf("कमेंट बॉक्स ढूँढ रहा हूँ" to { click(COMMENT) }))
            else run("कमेंट", listOf(
                "कमेंट बॉक्स ढूँढ रहा हूँ" to { click(COMMENT) },
                "टेक्स्ट बॉक्स चुन रहा हूँ" to { click(COMMENT, true, 2500); true },
                "'$text' लिख रहा हूँ" to { type(text) },
                "पोस्ट कर रहा हूँ" to { click(POST) }
            ))
            return
        }

        if (tokens[0] in TYPEW && tokens.size > 1) {
            val text = raw.split(Regex("\\s+")).drop(1).joinToString(" ")
            run("टाइपिंग", listOf("'$text' लिख रहा हूँ" to { type(text) }))
            return
        }

        if (tokens.size <= 3) {
            val g = when {
                tokens.any { it in BACK } -> GLOBAL_ACTION_BACK to "वापस जा रहा हूँ"
                tokens.any { it in HOME } -> GLOBAL_ACTION_HOME to "होम पर जा रहा हूँ"
                tokens.any { it in RECENT } -> GLOBAL_ACTION_RECENTS to "रिसेंट खोल रहा हूँ"
                tokens.any { it in NOTIF } -> GLOBAL_ACTION_NOTIFICATIONS to "नोटिफिकेशन खोल रहा हूँ"
                else -> null
            }
            if (g != null) { run(g.second, listOf(g.second to { performGlobalAction(g.first) })); return }
        }

        if (tokens.any { it in SCROLLW } || (tokens.size <= 2 && tokens.any { it in UP + DOWN + LEFT + RIGHT })) {
            val dir = when {
                tokens.any { it in UP } -> "up"
                tokens.any { it in LEFT } -> "left"
                tokens.any { it in RIGHT } -> "right"
                else -> "down"
            }
            val name = mapOf("up" to "ऊपर", "down" to "नीचे", "left" to "बाएं", "right" to "दाएं")[dir]
            run("स्क्रॉल", listOf("$name स्क्रॉल कर रहा हूँ" to { scroll(dir) }))
            return
        }

        val target = tokens.filter { it !in OPEN && it !in CLICK && it !in FILL }.joinToString(" ")

        if (tokens.any { it in OPEN } && target.isNotBlank()) {
            run("ऐप खोलना", listOf("$target खोल रहा हूँ" to { openApp(target) }))
            return
        }
        if (tokens.any { it in CLICK } && target.isNotBlank()) {
            run("क्लिक", listOf("'$target' ढूँढ रहा हूँ" to { click(listOf(target)) }))
            return
        }

        // Only a word was spoken: installed app name -> open it, otherwise click that word on screen.
        if (tokens.size <= 3 && Apps.find(this, target, 0.75) != null) {
            run("ऐप खोलना", listOf("$target खोल रहा हूँ" to { openApp(target) }))
        } else {
            run("क्लिक", listOf("'$target' ढूँढ रहा हूँ" to { click(listOf(target)) }))
        }
    }

    private fun sendMsg(appQ: String, name: String, text: String) {
        run("संदेश भेजना", listOf(
            "$appQ खोल रहा हूँ" to { openApp(appQ) },
            "सर्च दबा रहा हूँ" to { click(SEARCH) },
            "'$name' लिख रहा हूँ" to { type(name) },
            "'$name' चुन रहा हूँ" to { nap(1200); click(listOf(name), false) },
            "मैसेज बॉक्स ढूँढ रहा हूँ" to { click(MSGBOX, true) },
            "'$text' लिख रहा हूँ" to { type(text) },
            "भेज रहा हूँ" to { click(SEND, false) }
        ))
    }

    // ---------------------------------------------------------------- step runner

    private fun run(title: String, steps: List<Pair<String, () -> Boolean>>) {
        for ((label, fn) in steps) {
            if (cancel) return
            ov.say(label)
            val ok = try { fn() } catch (e: Exception) { false }
            if (cancel) return
            if (!ok) { ov.say("$label — नहीं हो पाया", false); return }
            ov.say("$label — हो गया", true)
            nap(700)
        }
        ov.say("$title पूरा", true)
    }

    private fun nap(ms: Long) {
        var left = ms
        while (left > 0 && !cancel) { Thread.sleep(minOf(left, 100)); left -= 100 }
    }

    // ---------------------------------------------------------------- actions

    private fun openApp(q: String): Boolean {
        val a = Apps.find(this, q) ?: return false
        val intent = packageManager.getLaunchIntentForPackage(a.second) ?: return false
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val end = SystemClock.uptimeMillis() + 8000
        while (SystemClock.uptimeMillis() < end && !cancel) {
            nap(300)
            if (rootInActiveWindow?.packageName == a.second) { nap(1500); return true }
        }
        return false
    }

    private fun click(qs: List<String>, edit: Boolean? = null, wait: Long = 6000): Boolean {
        val end = SystemClock.uptimeMillis() + wait
        while (SystemClock.uptimeMillis() < end && !cancel) {
            val hit = Finder.best(rootInActiveWindow, qs, edit)
            if (hit != null) {
                val r = Rect()
                hit.getBoundsInScreen(r)
                ov.point(r.centerX(), r.centerY())
                nap(700)
                doClick(hit, r)
                nap(500)
                return true
            }
            nap(400)
        }
        return false
    }

    private fun doClick(node: AccessibilityNodeInfo, r: Rect) {
        if (node.isEditable) { node.performAction(AccessibilityNodeInfo.ACTION_CLICK); node.performAction(AccessibilityNodeInfo.ACTION_FOCUS); return }
        var n: AccessibilityNodeInfo? = node
        var d = 0
        while (n != null && d < 7) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            n = n.parent
            d++
        }
        gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 60)
    }

    private fun type(text: String): Boolean {
        nap(500)
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: Finder.firstEditable(root) ?: return false
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val ok = f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        nap(500)
        return ok
    }

    private fun scroll(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val (x1, y1, x2, y2) = when (dir) {
            "up" -> listOf(w / 2, h * 0.30f, w / 2, h * 0.75f)
            "down" -> listOf(w / 2, h * 0.75f, w / 2, h * 0.30f)
            "left" -> listOf(w * 0.80f, h / 2, w * 0.20f, h / 2)
            else -> listOf(w * 0.20f, h / 2, w * 0.80f, h / 2)
        }
        ov.swipe(x1, y1, x2, y2, 700)
        nap(300)
        return gesture(x1, y1, x2, y2, 600)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        val latch = CountDownLatch(1)
        var ok = false
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(4, TimeUnit.SECONDS)
        return ok
    }
}
