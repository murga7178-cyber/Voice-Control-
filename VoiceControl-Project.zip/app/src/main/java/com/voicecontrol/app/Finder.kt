package com.voicecontrol.app

import android.view.accessibility.AccessibilityNodeInfo

object Finder {
    /** Best matching visible node. edit: true = only text fields, false = only non-fields, null = any. */
    fun best(root: AccessibilityNodeInfo?, qs: List<String>, edit: Boolean?): AccessibilityNodeInfo? {
        if (root == null) return null
        var best: AccessibilityNodeInfo? = null
        var bs = 0.0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isVisibleToUser && (edit == null || n.isEditable == edit)) {
                for (f in listOf(n.text, n.contentDescription, n.hintText)) {
                    if (f.isNullOrEmpty()) continue
                    for (q in qs) {
                        val s = Match.score(q, f.toString())
                        if (s > bs) { bs = s; best = n }
                    }
                }
                val id = n.viewIdResourceName?.substringAfter('/')?.replace('_', ' ')
                if (id != null) for (q in qs) {
                    if (Match.contains(q, id) && 0.9 > bs) { bs = 0.9; best = n }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return if (bs >= VoiceService.MIN_SCORE) best else null
    }

    fun firstEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) firstEditable(n.getChild(i))?.let { return it }
        return null
    }
}
