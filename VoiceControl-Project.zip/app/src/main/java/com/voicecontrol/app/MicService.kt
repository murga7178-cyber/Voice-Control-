package com.voicecontrol.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Keeps listening (Hindi + English words) and hands every sentence to VoiceService. */
class MicService : Service() {
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") {
            running = false
            rec?.destroy(); rec = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            VoiceService.instance?.status("सुनना बंद")
            return START_NOT_STICKY
        }
        val ch = "mic"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Voice Control सुन रहा है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        VoiceService.instance?.status("सुन रहा हूँ… बोलिए")
        listen()
        return START_STICKY
    }

    private fun listen() {
        if (!running) return
        try { listenNow() } catch (e: Throwable) { again(3000) }
    }

    private fun listenNow() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        ?.let { VoiceService.instance?.onHeard(it) }
                    again()
                }
                override fun onError(e: Int) = again(if (e == 8 || e == 9) 2500 else 300)
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        rec?.startListening(i)
    }

    private fun again(ms: Long = 300) { h.postDelayed({ listen() }, ms) }

    override fun onDestroy() { running = false; rec?.destroy(); super.onDestroy() }
}
