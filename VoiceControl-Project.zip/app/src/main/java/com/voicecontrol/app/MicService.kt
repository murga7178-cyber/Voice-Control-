package com.voicecontrol.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Keeps listening (Hindi + English words) and hands every sentence to VoiceService. */
class MicService : Service() {
    companion object {
        @Volatile private var live: MicService? = null
        fun speak(text: String) {
            try { live?.tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "voice_feedback") } catch (_: Throwable) { }
        }
    }
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var activeSession = false
    private var lastCommandAt = 0L
    private var tts: TextToSpeech? = null

    private fun isWakeWord(text: String): Boolean {
        val n = text.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N} ]"), " ")
            .replace(Regex("\\s+"), " ").trim()
        val words = n.split(" ").toSet()
        return n in setOf("hello", "hello voice control", "hi", "hi voice control", "हेलो", "हलो", "हेलो सुनो", "हाय", "सुनो", "सुनो जी", "सुनिए", "सुनाओ", "suno", "suniye")
    }

    private fun announceWake() {
        VoiceService.instance?.status("हाँ, मैं सुन रही हूँ। बताइए आपको क्या चाहिए।")
        try { tts?.speak("हाँ, मैं सुन रही हूँ। बताइए आपको क्या चाहिए।", TextToSpeech.QUEUE_FLUSH, null, "wake_ack") } catch (_: Throwable) { }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") {
            running = false
            activeSession = false
            rec?.destroy(); rec = null
            tts?.stop(); tts?.shutdown(); tts = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            VoiceService.instance?.status("सुनना बंद")
            return START_NOT_STICKY
        }
        val ch = "mic"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Voice", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Voice Control सुन रहा है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        live = this
        running = true
        activeSession = false
        if (tts == null) tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                try { tts?.language = Locale("hi", "IN") } catch (_: Throwable) { }
            }
        }
        VoiceService.instance?.status("'हेलो', 'हाय' या 'सुनो' बोलें")
        listen()
        return START_STICKY
    }

    private fun listen() {
        if (!running) return
        if (activeSession && SystemClock.elapsedRealtime() - lastCommandAt > 25000) {
            activeSession = false
            VoiceService.instance?.status("अब 'हेलो', 'हाय' या 'सुनो' बोलें")
        }
        try { listenNow() } catch (e: Throwable) { again(3000) }
    }

    private fun listenNow() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val heard = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (!activeSession) {
                        if (heard.isNotBlank() && isWakeWord(heard)) {
                            activeSession = true
                            lastCommandAt = SystemClock.elapsedRealtime()
                            announceWake()
                            again(2600)
                        } else again(250)
                    } else {
                        if (heard.isNotBlank() && !isWakeWord(heard)) {
                            lastCommandAt = SystemClock.elapsedRealtime()
                            VoiceService.instance?.onHeard(heard)
                        }
                        if (SystemClock.elapsedRealtime() - lastCommandAt > 25000) {
                            activeSession = false
                            VoiceService.instance?.status("अब 'हेलो', 'हाय' या 'सुनो' बोलें")
                        }
                        again(350)
                    }
                }
                override fun onError(e: Int) {
                    if (activeSession && SystemClock.elapsedRealtime() - lastCommandAt > 25000) {
                        activeSession = false
                        VoiceService.instance?.status("अब 'हेलो', 'हाय' या 'सुनो' बोलें")
                    }
                    again(if (e == 8 || e == 9) 2500 else 300)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        rec?.startListening(i)
    }

    private fun again(ms: Long = 300) { h.postDelayed({ listen() }, ms) }

    override fun onDestroy() { live = null; running = false; rec?.destroy(); tts?.stop(); tts?.shutdown(); tts = null; super.onDestroy() }
}
