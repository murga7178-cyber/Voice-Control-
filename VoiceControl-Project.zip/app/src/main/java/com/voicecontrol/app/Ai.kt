package com.voicecontrol.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Optional: sends the spoken sentence to Claude, gets back a list of actions (and an optional time). */
object Ai {
    private const val MODEL = "claude-haiku-5-5"
    private const val SYS = """You turn a spoken command for an Android phone into JSON. The user speaks Hindi (Devanagari), English or mixed Hinglish; speech recognition makes mistakes, so infer the intended meaning and fix obvious mistakes.
Reply with ONLY one JSON object and nothing else:
{"at":null,"steps":[...],"note":""}
"at": 24-hour "HH:MM" if the user wants it done later ("around 10" -> "10:00", "सुबह 9 बजे" -> "09:00", "शाम 6" -> "18:00"), otherwise null.
Each step is one of:
{"a":"open","app":"whatsapp"}
{"a":"message","app":"whatsapp","name":"person name","text":"message to send"}
{"a":"click","text":"text visible on screen"}
{"a":"type","text":"..."}
{"a":"comment","text":"..."}
{"a":"scroll","dir":"up|down|left|right"}
{"a":"back"}
{"a":"home"}
{"a":"lock"}
{"a":"wait","sec":2}
Rules: use "message" for any request to send someone a message (it opens the app, finds the chat, types and sends). Keep the person's name as spoken. For the message text write what the user wants sent; if they only describe it (for example "wish good morning"), write a natural short message in the language and script the user used. App names in English letters. If the user asks to lock the screen or turn the screen off when the work is done, add {"a":"lock"} as the very last step. If you cannot understand the request, return an empty steps list and a short Hindi explanation in "note"."""

    fun key(ctx: Context): String = ctx.getSharedPreferences("p", 0).getString("key", "")?.trim().orEmpty()

    fun plan(ctx: Context, said: String): JSONObject {
        val now = SimpleDateFormat("EEEE HH:mm", Locale.ENGLISH).format(Date())
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 700)
            .put("system", SYS)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "Now: $now\nSaid: $said")))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = 25000
        c.doOutput = true
        c.setRequestProperty("x-api-key", key(ctx))
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw Exception("API $code")
        val arr = JSONObject(txt).getJSONArray("content")
        var out = ""
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") == "text") { out = o.getString("text"); break }
        }
        return JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    }
}
