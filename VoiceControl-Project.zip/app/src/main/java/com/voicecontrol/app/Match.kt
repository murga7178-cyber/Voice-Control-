package com.voicecontrol.app

/** Text matching: Hindi/English, partial match allowed (see VoiceService.MIN_SCORE). */
object Match {
    fun norm(s: String) = s.lowercase()
        .replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private val cons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n", 'त' to "t", 'थ' to "th", 'द' to "d",
        'ध' to "dh", 'न' to "n", 'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y",
        'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h"
    )
    private val vow = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u", 'ए' to "e", 'ऐ' to "ai",
        'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u",
        'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ं' to "n", 'ँ' to "n", 'ः' to "h",
        '्' to "", '़' to ""
    )

    /** Devanagari -> rough Latin, so "राहुल" can match "Rahul". */
    fun translit(s: String): String {
        val sb = StringBuilder()
        for (i in s.indices) {
            val c = s[i]
            val k = cons[c]
            if (k != null) {
                sb.append(k)
                val n = s.getOrNull(i + 1)
                if (n != null && (cons.containsKey(n) || n == 'ं' || n == 'ँ')) sb.append('a')
            } else sb.append(vow[c] ?: c.toString())
        }
        return sb.toString()
    }

    /** 0.0 .. 1.0 how much of [q] is found in [t]. */
    fun score(q: String, t: String): Double {
        val a = norm(q)
        val b = norm(t)
        if (a.isEmpty() || b.isEmpty()) return 0.0
        var best = 0.0
        for (x in setOf(a, translit(a))) for (y in setOf(b, translit(b))) best = maxOf(best, one(x, y))
        return best
    }

    fun contains(q: String, t: String) = norm(t).contains(norm(q)) && norm(q).isNotEmpty()

    private fun one(a: String, b: String): Double {
        if (b.contains(a) || (b.length >= 3 && a.contains(b))) return 1.0
        var best = 0
        val dp = IntArray(b.length + 1)
        for (i in 1..a.length) {
            var prev = 0
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev + 1 else 0
                if (dp[j] > best) best = dp[j]
                prev = tmp
            }
        }
        return if (best < 2) 0.0 else best.toDouble() / a.length
    }
}
