package com.voicecontrol.app

import android.app.Application
import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter

class App : Application() {
    override fun onCreate() { super.onCreate(); Crash.install(this) }
}

/** Saves the last crash text so the main screen can show it. */
object Crash {
    private class H(val c: Context, val old: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                c.getSharedPreferences("p", 0).edit().putString("crash", sw.toString().take(1200)).commit()
            } catch (x: Throwable) { }
            old?.uncaughtException(t, e)
        }
    }

    fun install(ctx: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        if (old is H) return
        Thread.setDefaultUncaughtExceptionHandler(H(ctx.applicationContext, old))
    }
}
