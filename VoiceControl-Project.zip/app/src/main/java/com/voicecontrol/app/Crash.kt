package com.voicecontrol.app

import android.app.Application
import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class App : Application() {
    override fun onCreate() { super.onCreate(); Crash.install(this); Crash.note(this, "process start") }
}

/** Saves the last crash text so the main screen can show it. */
object Crash {
    private class H(val c: Context, val old: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                c.getSharedPreferences("p", 0).edit().putString("crash", sw.toString().take(1200)).commit()
            } catch (x: Throwable) { }
            old?.uncaughtException(t, e)
        }
    }

    /** Small timeline (kept on the phone) to see when the service connects / disconnects. */
    fun note(ctx: Context, msg: String) {
        try {
            val sp = ctx.getSharedPreferences("p", 0)
            val old = sp.getString("log", "") ?: ""
            val line = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH).format(Date()) + " " + msg
            sp.edit().putString("log", (old + "\n" + line).takeLast(700)).commit()
        } catch (e: Throwable) { }
    }

    fun install(ctx: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        if (old is H) return
        Thread.setDefaultUncaughtExceptionHandler(H(ctx.applicationContext, old))
    }
}
